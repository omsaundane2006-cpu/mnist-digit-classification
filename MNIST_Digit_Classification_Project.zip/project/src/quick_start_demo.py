"""
Handwritten Digit Classification - Sample Project
====================================================
A complete, runnable digit-classification pipeline.

This sample uses scikit-learn's built-in `load_digits` dataset
(8x8 grayscale digit images, no internet download required) so it
runs anywhere out of the box. Swap in the full 28x28 MNIST dataset
(60,000 training images) by following the note at the bottom of
this file once you have internet access.
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.svm import SVC

# ----------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------
digits = load_digits()
X, y = digits.data, digits.target          # X: (1797, 64) flattened 8x8 images
print(f"Dataset shape: {X.shape}, classes: {np.unique(y)}")

# ----------------------------------------------------------------
# 2. Train / test split
# ----------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ----------------------------------------------------------------
# 3. Preprocess (scale pixel values)
# ----------------------------------------------------------------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ----------------------------------------------------------------
# 4. Train two models to compare
# ----------------------------------------------------------------
models = {
    "MLP (Neural Network)": MLPClassifier(
        hidden_layer_sizes=(128, 64),
        activation="relu",
        max_iter=300,
        random_state=42,
    ),
    "SVM (RBF kernel)": SVC(kernel="rbf", gamma="scale"),
}

results = {}
for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    preds = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, preds)
    results[name] = (model, preds, acc)
    print(f"\n{name} — Test Accuracy: {acc:.4f}")
    print(classification_report(y_test, preds, digits=3))

# ----------------------------------------------------------------
# 5. Pick the best model and visualize results
# ----------------------------------------------------------------
best_name = max(results, key=lambda k: results[k][2])
best_model, best_preds, best_acc = results[best_name]
print(f"\nBest model: {best_name} ({best_acc:.4f} accuracy)")

# Confusion matrix
cm = confusion_matrix(y_test, best_preds)
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

im = axes[0].imshow(cm, cmap="Blues")
axes[0].set_title(f"Confusion Matrix — {best_name}")
axes[0].set_xlabel("Predicted label")
axes[0].set_ylabel("True label")
axes[0].set_xticks(range(10))
axes[0].set_yticks(range(10))
for i in range(10):
    for j in range(10):
        axes[0].text(j, i, cm[i, j], ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
plt.colorbar(im, ax=axes[0], fraction=0.046)

# Sample predictions (first 8 test images)
axes[1].axis("off")
n_show = 8
sub_fig = fig.add_subplot(1, 2, 2)
sub_fig.axis("off")
for i in range(n_show):
    ax_i = fig.add_axes([0.55 + (i % 4) * 0.11, 0.55 - (i // 4) * 0.35, 0.09, 0.3])
    ax_i.imshow(X_test[i].reshape(8, 8), cmap="gray")
    color = "green" if best_preds[i] == y_test[i] else "red"
    ax_i.set_title(f"P:{best_preds[i]} T:{y_test[i]}", color=color, fontsize=9)
    ax_i.axis("off")

plt.tight_layout()
plt.savefig("digit_classification_results.png", dpi=150, bbox_inches="tight")
print("\nSaved visualization to digit_classification_results.png")

# ----------------------------------------------------------------
# NOTE: Scaling up to full MNIST (60,000 28x28 images)
# ----------------------------------------------------------------
# Once you have internet access, replace the data-loading section with:
#
#   from tensorflow.keras.datasets import mnist
#   (X_train, y_train), (X_test, y_test) = mnist.load_data()
#   X_train = X_train.reshape(-1, 28*28) / 255.0
#   X_test  = X_test.reshape(-1, 28*28) / 255.0
#
# For best results on full MNIST, use a CNN (Conv2D + MaxPooling + Dense)
# instead of MLPClassifier — it will comfortably exceed 99% accuracy.
