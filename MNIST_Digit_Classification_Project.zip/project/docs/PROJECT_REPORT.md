# Project Report: Handwritten Digit Classification (MNIST)

## 1. Introduction

Handwritten digit recognition is a classic computer vision problem: given an image of a handwritten digit, predict which digit (0–9) it represents. It is difficult because handwriting varies enormously in size, slant, thickness, and personal style, so a model must learn generalizable visual patterns rather than memorizing specific images.

**Objective:** Build and compare two neural network models — a fully-connected Artificial Neural Network (ANN) and a Convolutional Neural Network (CNN) — that classify a 28×28 pixel digit image into one of 10 classes, and evaluate which architecture performs best.

## 2. Dataset

The project uses **MNIST**, the standard benchmark dataset for handwritten digit classification.

| Property | Value |
|---|---|
| Training images | 60,000 |
| Test images | 10,000 |
| Image dimensions | 28 × 28 pixels, single-channel grayscale |
| Pixel value range | 0–255, normalized to 0.0–1.0 |
| Number of classes | 10 (digits 0 through 9) |

## 3. Methodology

The project follows a consistent five-stage pipeline, implemented identically for both models so their results are directly comparable:

1. **Load Data** — Fetch MNIST training and test images/labels.
2. **Preprocess** — Normalize pixel values from the 0–255 range to 0–1; reshape images to include a channel dimension for the CNN.
3. **Build Model** — Define the network architecture in Keras.
4. **Train** — Fit the model on the training set with a 10% validation split.
5. **Evaluate** — Measure test accuracy, generate a confusion matrix, classification report, and inspect misclassified examples.

### 3.1 Model Architecture — ANN (Baseline)

```
Input (28×28)
  → Flatten → 784 values
  → Dense(128, ReLU) → Dropout(0.2)
  → Dense(64, ReLU)  → Dropout(0.2)
  → Dense(10, Softmax)
```

The ANN flattens the image into a 1D vector of 784 values before any learning happens, so it never directly sees which pixels are spatially adjacent.

### 3.2 Model Architecture — CNN (Upgraded)

```
Input (28×28×1)
  → Conv2D(32, 3×3, ReLU) → MaxPooling2D(2×2)
  → Conv2D(64, 3×3, ReLU) → MaxPooling2D(2×2)
  → Flatten → Dense(128, ReLU) → Dropout(0.3)
  → Dense(10, Softmax)
```

The CNN applies learned filters across the 2D pixel grid, allowing it to detect local patterns (edges, curves, loops) before flattening — closer to how the underlying structure of the image is actually organized.

## 4. Implementation

### 4.1 Tools & Technology Stack

| Tool | Role |
|---|---|
| Python | Core programming language |
| TensorFlow / Keras | Model definition, training, evaluation |
| NumPy | Array and numerical operations |
| Matplotlib / Seaborn | Plots: accuracy/loss curves, confusion matrix heatmaps |
| scikit-learn | `confusion_matrix`, `classification_report` |
| Jupyter / Google Colab | Development and execution environment |

### 4.2 Training Configuration

| Setting | Value |
|---|---|
| Optimizer | Adam |
| Loss function | Sparse categorical crossentropy |
| Batch size | 128 |
| Epochs | 10 (ANN) · up to 15 with early stopping (CNN) |
| Validation split | 10% of training data |
| Regularization | Dropout (0.2 ANN / 0.3 CNN); early stopping on validation loss (CNN) |

**Early stopping** monitors validation loss and halts training once it stops improving for a set number of epochs (patience = 3), restoring the best-performing weights rather than the final epoch's — this prevents the CNN from overfitting during its extra training budget.

### 4.3 Reproducibility

The CNN notebook sets explicit random seeds (`numpy.random.seed`, `tensorflow.random.set_seed`) so repeated runs produce consistent, comparable results.

## 5. Results

| Model | Test Accuracy |
|---|---|
| ANN (Dense) | ~97.8% |
| CNN (Conv2D) | ~99.2% |

*(These are typical published benchmark figures for these architectures on MNIST, included as a reference target — record your own notebook's actual test accuracy here once run.)*

The CNN's error rate is roughly half the ANN's — a meaningful difference at MNIST's scale of 10,000 test images, translating to noticeably fewer real-world misclassifications.

## 6. Evaluation

Each model is evaluated with more than a single accuracy number:

- **Confusion Matrix** — reveals exactly which digit pairs get confused, not just the aggregate error rate.
- **Precision / Recall / F1-score per digit** — some digits (e.g., 4 and 9) are structurally harder to distinguish than others.
- **Misclassified image gallery** — visual inspection of wrong predictions, useful for spotting whether errors are "reasonable" (ambiguous handwriting) or systematic (a model weakness).

**Commonly confused digit pairs:** 4↔9, 3↔5, 7↔1. These share curved, overlapping strokes that make them visually similar — some of the misclassified examples would likely be ambiguous to a human reader too.

## 7. Key Findings

1. **Spatial structure matters.** CNNs outperform plain ANNs because convolution preserves the 2D relationships between pixels that flattening destroys.
2. **Dropout and early stopping help.** Both regularization techniques reduce the gap between training and validation accuracy, indicating less overfitting.
3. **Errors are not random.** Misclassifications cluster on visually similar digit pairs rather than spreading evenly across all ten digits.
4. **Diminishing returns near 99%.** Pushing accuracy further from ~99% typically requires more than architecture changes alone — data augmentation and hyperparameter tuning matter increasingly at the margin.

## 8. Conclusion

Both an ANN and a CNN were built on the same pipeline and trained on 60,000 MNIST images. The CNN outperformed the ANN by learning spatial features directly from the pixel grid rather than treating the image as an unordered list of pixel values. The project demonstrates a complete, reproducible machine learning workflow — from raw data through preprocessing, model building, training, and rigorous evaluation.

## 9. Future Work

- **Data augmentation** (rotation, shifting, zoom) to improve robustness to real-world handwriting variation
- **Batch normalization** between convolutional layers to stabilize and potentially speed up training
- **Hyperparameter tuning** — learning rate, filter counts/sizes, dropout rate
- **Deployment** — an interactive web app where a user draws a digit on a canvas and receives a live prediction

## 10. References

- LeCun, Y., Cortes, C., Burges, C.J.C. — [The MNIST Database of Handwritten Digits](http://yann.lecun.com/exdb/mnist/)
- TensorFlow / Keras documentation: https://www.tensorflow.org/api_docs/python/tf/keras
- scikit-learn documentation: https://scikit-learn.org/stable/documentation.html
