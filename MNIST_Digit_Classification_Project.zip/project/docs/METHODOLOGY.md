# Methodology Reference

Quick reference for the pipeline and architectures used in both notebooks. See `PROJECT_REPORT.md` for full narrative detail.

## Pipeline

```
1. Load Data      → tf.keras.datasets.mnist.load_data()
2. Preprocess      → normalize pixels to [0, 1]; reshape for CNN input (28,28,1)
3. Build Model     → Sequential Keras model (ANN or CNN)
4. Train           → model.fit(..., validation_split=0.10)
5. Evaluate        → model.evaluate(); confusion matrix; classification report
```

## ANN Architecture

| Layer | Output Shape | Notes |
|---|---|---|
| Input | (28, 28) | Raw grayscale image |
| Flatten | (784,) | Collapses image to a 1D vector |
| Dense | (128,) | ReLU activation |
| Dropout | (128,) | Rate 0.2 |
| Dense | (64,) | ReLU activation |
| Dropout | (64,) | Rate 0.2 |
| Dense | (10,) | Softmax — class probabilities |

## CNN Architecture

| Layer | Output Shape (approx.) | Notes |
|---|---|---|
| Input | (28, 28, 1) | Adds channel dimension |
| Conv2D | (26, 26, 32) | 3×3 kernel, ReLU |
| MaxPooling2D | (13, 13, 32) | 2×2 pool |
| Conv2D | (11, 11, 64) | 3×3 kernel, ReLU |
| MaxPooling2D | (5, 5, 64) | 2×2 pool |
| Flatten | (1600,) | |
| Dense | (128,) | ReLU activation |
| Dropout | (128,) | Rate 0.3 |
| Dense | (10,) | Softmax — class probabilities |

## Training Hyperparameters

| Parameter | ANN | CNN |
|---|---|---|
| Optimizer | Adam | Adam |
| Loss | Sparse categorical crossentropy | Sparse categorical crossentropy |
| Batch size | 128 | 128 |
| Epochs | 10 | Up to 15 (early stopping, patience=3) |
| Validation split | 10% | 10% |
| Dropout | 0.2 | 0.3 |

## Evaluation Checklist

- [ ] Test accuracy and loss
- [ ] Training vs. validation accuracy/loss curves (check for overfitting)
- [ ] Confusion matrix
- [ ] Precision / recall / F1-score per class
- [ ] Sample of correct predictions
- [ ] Sample of misclassified predictions
- [ ] Saved model reloads and reproduces test accuracy
